

Welcome to the Citadel system!

Documentation is no longer included with the source code distribution;
instead we encourage you to visit http://www.citadel.org and peruse the
knowledge base we have online at the web site.

