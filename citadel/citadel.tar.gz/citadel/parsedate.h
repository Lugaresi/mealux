
time_t parsedate(const char *);
