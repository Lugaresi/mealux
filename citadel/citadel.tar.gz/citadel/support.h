#include <stdio.h>

void strproc (char *string);
int getstring (FILE *fp, char *string);
