void ical_dezonify(icalcomponent *cal);
icaltimezone *get_default_icaltimezone(void);
