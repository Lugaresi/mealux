#ifndef AXDEFS

char *axdefs[]={
	"Deleted",
	"New User",
	"Problem User",
	"Local User",
	"Network User",
	"Preferred User",
	"Admin",
	"Admin"
};

#define AXDEFS 1

#else

extern char *axdefs[];

#endif




#ifndef VIEWDEFS

char *viewdefs[]={
	"Messages",
	"Summary",
	"Address book",
	"Calendar",
	"Tasks"
};

#define VIEWDEFS 1

#else

extern char *viewdefs[];

#endif

