

const char *svn_revision(void);


