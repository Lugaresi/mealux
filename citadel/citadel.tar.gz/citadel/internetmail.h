void LoadInternetConfig(void);
int IsHostLocal(char *WhichHost);
