
int validate_password(uid_t uid, const char *pass);
