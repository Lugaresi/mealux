 
 * Full documentation is at http://www.citadel.org.

 * The condensed version:
 
   1. Create a user on your system under which to run Citadel
   2. Install supported versions of Berkeley DB, libical, and libsieve.
   3. ./configure && make && make install
   4. Run the "setup" program
 
 * After installing Citadel, you'll probably want to install WebCit
   so that you can access the Citadel system using a web browser.

 * Keep in mind that there is a FAQ at http://www.citadel.org
