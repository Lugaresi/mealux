#ifndef FILE_OPS_H
#define FILE_OPS_H

#include "context.h"

void OpenCmdResult (char *, const char *);
void abort_upl (CitContext *who);


#endif /* FILE_OPS_H */
