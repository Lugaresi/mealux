void GetExpirePolicy(struct ExpirePolicy *epbuf, struct ctdlroom *qrbuf);
void cmd_gpex(char *argbuf);
void cmd_spex(char *argbuf);
