void network_deliver_digest(SpoolControl *sc);
void network_spool_msg(long msgnum, void *userdata);
